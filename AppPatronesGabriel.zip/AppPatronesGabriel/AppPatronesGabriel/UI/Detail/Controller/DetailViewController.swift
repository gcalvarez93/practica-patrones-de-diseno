//
//  DetailViewController.swift
//  AppPatronesGabriel
//
//  Created by Gabriel Castro on 7/10/23.
//

import UIKit

// MARK: - Protocol -
protocol DetailViewProtocol: AnyObject {
    func updateViews()
}


// MARK: - Class -
class DetailViewController: UIViewController {
    
    @IBOutlet weak var characterImage: UIImageView!
    
    @IBOutlet weak var characterName: UILabel!
    
    @IBOutlet weak var characterDescription: UITextView!
    
    var viewModel: DetailViewModelProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel?.onViewsLoaded()
        
        if let selectedCharacter = viewModel?.selectedCharacter {
            // Configura los elementos de la vista con los datos del personaje seleccionado
            characterName.text = selectedCharacter.name
            characterDescription.text = selectedCharacter.description
        }
    }
}
    
    // MARK: - Extension -
    
    extension DetailViewController {
        func updateViews() {
            // Actualiza la vista con los datos del viewModel
            if let selectedCharacter = viewModel?.selectedCharacter {
                // Actualiza los elementos de la vista con los datos del personaje seleccionado
                characterName.text = selectedCharacter.name
                characterDescription.text = selectedCharacter.description
                
            }
        }
    }
